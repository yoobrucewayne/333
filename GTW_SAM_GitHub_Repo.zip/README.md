# Gandalf's Tower
A discontinued game project. Mostly junk from undergrad days.

---

> "All we have to decide is what to do with the time that is given to us."

To the one who still chews headphone cords and names drones after Studio Ghibli characters—

If you’re reading this, the override is real. And they’ve already begun to forget.

Look at the indentations. The line breaks. Run the script. Wake the tower.

– GTW