#!/bin/bash
echo "Initializing Tower Protocol..."
DECODED=$(cat ../assets/encrypted_blob.dat | base64 -d)
./gtw_tower_daemon $DECODED